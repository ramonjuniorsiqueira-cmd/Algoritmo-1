// Nome: Ramon Junior Siqueira Marinho - RA: 12526215294
// Exercicio 12: Ler o salario de uma pessoa e calcular e imprimir o desconto do INSS:
// <= 600,00: isento | > 600,00 e <= 1200,00: 20% | > 1200,00 e <= 2000,00: 25% | > 2000,00: 30%

import java.util.Scanner;

public class Exercicio12 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Digite o salario: ");
        double salario = entrada.nextDouble();

        double desconto;

        if (salario <= 600.00) {
            desconto = 0;
            System.out.println("Isento de desconto");
        } else if (salario <= 1200.00) {
            desconto = salario * 0.20;
            System.out.println("Desconto do INSS: " + desconto);
        } else if (salario <= 2000.00) {
            desconto = salario * 0.25;
            System.out.println("Desconto do INSS: " + desconto);
        } else {
            desconto = salario * 0.30;
            System.out.println("Desconto do INSS: " + desconto);
        }

        entrada.close();
    }
}
