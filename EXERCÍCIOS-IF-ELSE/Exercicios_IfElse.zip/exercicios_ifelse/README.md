# Exercícios - Desvio Condicional (if / else if / else)

**Nome:** Ramon Junior Siqueira Marinho
**RA:** 12526215294

Lista de exercícios da aula de Desvio Condicional, com 13 algoritmos resolvidos em Java.

| Arquivo | Exercício |
|---|---|
| Exercicio1.java | Metade de um número > 20 |
| Exercicio2.java | Maior ou menor de idade |
| Exercicio3.java | Números iguais / diferença |
| Exercicio4.java | Ordem decrescente de dois números |
| Exercicio5.java | Pertence ao intervalo 50–100 |
| Exercicio6.java | Cálculo de peso ideal |
| Exercicio7.java | Bônus por tempo de empresa |
| Exercicio8.java | Validação de senha |
| Exercicio9.java | Empréstimo consignado |
| Exercicio10.java | Maior entre 3 números |
| Exercicio11.java | Categoria de nadador por idade |
| Exercicio12.java | Desconto do INSS |
| Exercicio13.java | Calculadora de operações básicas |
